@echo off
rem Rebuild from source with MinGW gcc (optional; the .exe files are already built)
gcc -std=gnu11 -O2 -o aerocore.exe main.c sched.c airline.c
gcc -std=gnu11 -O2 -o test_aerocore.exe test.c sched.c airline.c
