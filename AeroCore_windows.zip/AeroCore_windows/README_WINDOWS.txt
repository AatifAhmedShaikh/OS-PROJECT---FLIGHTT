AeroCore for Windows
====================

Run it (no compiler needed)
  1. Unzip this folder.
  2. Open Command Prompt in the folder (type cmd in the Explorer address bar).
  3. Start the program:      aerocore.exe
  4. At the aerocore> prompt type:   demo   then   run   then   compare   then   quit

Run the demo without typing:
     aerocore.exe < demo_input.txt

Other commands: help, flights, seats AC101, pax add 0300-1234567 Ayesha Khan,
book 1 AC101, pending, trace on, crash 2, txns, history 1, pnr <PNR>.
Your data is saved in aerocore.journal in the same folder (delete it to reset).

Self-check:  test_aerocore.exe   (prints ALL TESTS PASSED; the fork-based crash
test is skipped on Windows, but the 'crash 2' command still works)

Rebuild from source: install MinGW-w64 gcc and run build.bat.

If Windows SmartScreen warns about an unknown app: More info, then Run anyway.
These .exe files were cross-compiled (Zig, x86-64 Windows) and are not signed.
